package com.example.wifimaster;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 410;
    private WifiManager wifiManager;
    private LinearLayout resultsBox;
    private TextView statusText;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver scanReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            boolean updated = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false);
            if (updated) {
                showScanResults();
            } else {
                statusText.setText("لم يكتمل تحديث المسح. قد يعرض Android نتائج سابقة بسبب قيود النظام.");
                showScanResults();
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        buildUi();
        registerScanReceiver();
        updateConnectionStatus();
        requestNeededPermissions();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(7, 17, 31));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(22), dp(18), dp(28));
        scroll.addView(page);

        TextView title = text("⌁  WiFi MASTER", 25, Color.WHITE, true);
        page.addView(title);
        TextView subtitle = text("محلل شبكات Wi-Fi ومساعد الاتصال المصرّح", 13, 0xFF9DB0C7, false);
        page.addView(subtitle);

        statusText = text("جارٍ تجهيز فحص الشبكات…", 14, 0xFFBBD2E8, false);
        statusText.setPadding(dp(13), dp(12), dp(13), dp(12));
        statusText.setBackgroundColor(0xFF13263B);
        LinearLayout.LayoutParams sp = params();
        sp.topMargin = dp(18);
        page.addView(statusText, sp);

        Button scan = button("فحص الشبكات القريبة");
        scan.setOnClickListener(v -> startScan());
        page.addView(scan, topParams());

        Button wifiSettings = button("فتح إعدادات Wi-Fi في الهاتف");
        wifiSettings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        page.addView(wifiSettings, topParams());

        TextView heading = text("الشبكات المكتشفة", 18, Color.WHITE, true);
        LinearLayout.LayoutParams hp = params();
        hp.topMargin = dp(22);
        page.addView(heading, hp);

        resultsBox = new LinearLayout(this);
        resultsBox.setOrientation(LinearLayout.VERTICAL);
        page.addView(resultsBox, params());

        TextView disclaimer = text(
            "ملاحظات: يعرض التطبيق أسماء الشبكات وقوة الإشارة والتردد ونوع الحماية الظاهر في بث الشبكة. " +
            "لا يستخرج كلمات المرور ولا يكسر التشفير ولا يتصل بشبكات محمية نيابةً عنك. " +
            "قد يتطلب Android منح إذن الموقع وتفعيل خدمات الموقع لإظهار نتائج المسح، كما قد يقيّد عدد مرات المسح.",
            12, 0xFFFFD99A, false);
        disclaimer.setPadding(dp(12), dp(12), dp(12), dp(12));
        disclaimer.setBackgroundColor(0xFF302719);
        LinearLayout.LayoutParams dp = params();
        dp.topMargin = dp(18);
        page.addView(disclaimer, dp);

        setContentView(scroll);
    }

    private void registerScanReceiver() {
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(scanReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(scanReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void requestNeededPermissions() {
        List<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!needed.isEmpty()) {
            requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
        } else {
            startScan();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) {
            boolean fineGranted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            if (fineGranted) startScan();
            else statusText.setText("يلزم إذن الموقع أثناء الاستخدام حتى يسمح Android بعرض نتائج مسح Wi-Fi.");
        }
    }

    private boolean locationEnabled() {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (lm == null) return false;
        if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled();
        try {
            return Settings.Secure.getInt(getContentResolver(), Settings.Secure.LOCATION_MODE) != Settings.Secure.LOCATION_MODE_OFF;
        } catch (Exception e) { return false; }
    }

    private void startScan() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            return;
        }
        if (wifiManager == null) {
            statusText.setText("خدمة Wi-Fi غير متاحة على هذا الجهاز.");
            return;
        }
        if (!wifiManager.isWifiEnabled()) {
            statusText.setText("فعّل Wi-Fi من إعدادات الهاتف ثم أعد الفحص.");
            return;
        }
        if (!locationEnabled()) {
            statusText.setText("فعّل خدمات الموقع من إعدادات Android؛ بعض الإصدارات تشترط ذلك لمسح Wi-Fi.");
            return;
        }
        statusText.setText("جارٍ طلب مسح Wi-Fi… قد يقيّد Android تكرار عمليات المسح.");
        boolean accepted = wifiManager.startScan();
        if (!accepted) {
            statusText.setText("رفض Android بدء مسح جديد أو تم تقييده. سأحاول عرض آخر النتائج المتاحة.");
            showScanResults();
        }
    }

    private void showScanResults() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        List<ScanResult> scans;
        try {
            scans = wifiManager.getScanResults();
        } catch (SecurityException e) {
            statusText.setText("لم يسمح Android بقراءة نتائج المسح. راجع الأذونات.");
            return;
        }
        resultsBox.removeAllViews();
        if (scans == null || scans.isEmpty()) {
            statusText.setText("لا توجد نتائج متاحة حالياً. تأكد من تشغيل Wi-Fi والموقع ثم أعد المحاولة.");
            return;
        }
        Collections.sort(scans, (a, b) -> Integer.compare(b.level, a.level));
        statusText.setText(String.format(Locale.getDefault(), "تم العثور على %d شبكة (قد تتضمن نتائج مخزنة مؤقتاً).", scans.size()));
        for (ScanResult r : scans) {
            String ssid = (r.SSID == null || r.SSID.isEmpty()) ? "(شبكة مخفية)" : r.SSID;
            int signal = WifiManager.calculateSignalLevel(r.level, 5);
            String security = securityLabel(r.capabilities);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(13), dp(11), dp(13), dp(11));
            card.setBackgroundColor(0xFF112238);
            LinearLayout.LayoutParams cp = params();
            cp.topMargin = dp(9);
            resultsBox.addView(card, cp);

            TextView name = text(ssid, 16, Color.WHITE, true);
            name.setTextDirection(View.TEXT_DIRECTION_LTR);
            name.setGravity(Gravity.RIGHT);
            card.addView(name);
            TextView detail = text("الحماية: " + security + "   •   الإشارة: " + signal + "/4", 12, 0xFFB7C9DD, false);
            card.addView(detail);
            TextView radio = text("التردد: " + r.frequency + " MHz   •   القناة: " + channelFromFrequency(r.frequency), 12, 0xFF8FA9C4, false);
            card.addView(radio);
        }
    }

    private String securityLabel(String caps) {
        if (caps == null || caps.isEmpty()) return "غير معروف";
        String c = caps.toUpperCase(Locale.ROOT);
        if (c.contains("WPA3")) return "WPA3 (أو مختلط)";
        if (c.contains("WPA2")) return "WPA2";
        if (c.contains("WPA")) return "WPA";
        if (c.contains("WEP")) return "WEP";
        if (c.contains("ESS")) return "مفتوحة / بدون تشفير ظاهر";
        return "غير معروف";
    }

    private int channelFromFrequency(int f) {
        if (f >= 2412 && f <= 2472) return (f - 2407) / 5;
        if (f == 2484) return 14;
        if (f >= 5000 && f <= 5900) return (f - 5000) / 5;
        if (f >= 5955 && f <= 7115) return (f - 5950) / 5;
        return 0;
    }

    private void updateConnectionStatus() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        Network n = cm == null ? null : cm.getActiveNetwork();
        NetworkCapabilities caps = n == null ? null : cm.getNetworkCapabilities(n);
        boolean wifi = caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        boolean validated = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        if (wifi && validated) statusText.setText("الهاتف متصل بشبكة Wi-Fi والإنترنت متاح. اضغط فحص الشبكات لعرض الشبكات القريبة.");
        else if (wifi) statusText.setText("الهاتف متصل بـ Wi-Fi، لكن لم يتم تأكيد توفر الإنترنت.");
        else statusText.setText("الهاتف غير متصل حالياً عبر Wi-Fi. يمكنك فحص الشبكات القريبة.");
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF147FCE));
        return b;
    }

    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private LinearLayout.LayoutParams topParams() {
        LinearLayout.LayoutParams p = params();
        p.topMargin = dp(9);
        return p;
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (receiverRegistered) {
            try { unregisterReceiver(scanReceiver); } catch (Exception ignored) {}
        }
    }
}
